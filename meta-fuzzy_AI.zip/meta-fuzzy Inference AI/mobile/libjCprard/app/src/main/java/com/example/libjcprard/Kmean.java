/*
 * Copyright (c) 2000, 2013, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */
 
package com.example.libjcprard;

public class Kmean{
	//1. dataset
	//double[] dataset={1,2,3.3,4.5,10,11,12,23.1,30,50,7};
	
	public double[][] kmean_algo(int iteration, double[] dataset_obj)
	{
		if(dataset_obj.length < 1)
		{
			return new double[3][1];
		}
	else{
		double[] dataset = dataset_obj;
				
		//*execute this when dataset size is less than centroid size*//
		int count = dataset.length;
		
		if(count < 3){
			double[] dataTemp = new double[3];
			
			for(int i = 0; i < dataset.length; i++ ){
				dataTemp[i] = dataset[i];
			}
			
		dataset = null;
		dataset = dataTemp;
		}
		//2. centroid
	double[][] class_set = new double[3][dataset.length];
	double[] centroid = new double[3];
	//3. distances
	double[][] distances = new double[centroid.length][dataset.length];
	
		
		for(int k = 0; k < iteration; k++){
		//initialize centroids
		if( k == 0){
		centroid[0] = (double)dataset[0];
		//System.out.println("c1 "+centroid[0]);
     	centroid[1] = (double)dataset[dataset.length / 2];
		//System.out.println("c1 "+centroid[1]);	
		centroid[2] = (double)dataset[dataset.length - 1];
		//System.out.println("c1 "+centroid[2]);

		}
		if(k > 0)
		{
			for(int i=0; i < centroid.length; i++){
				centroid[i] =sorted_out_Mean(class_set[i]);
				//System.out.println("centroid "+centroid[i]);
			}
		}
		//compute distances
		for(int j=0; j < centroid.length; j++)
			for(int i = 0; i < dataset.length; i++)
				distances[j][i] = Math.abs(dataset[i] - centroid[j]);
				
		for(int i = 0; i < class_set.length; i++)
			for(int j = 0; j < class_set[0].length; j++)
				class_set[i][j] = Double.POSITIVE_INFINITY;
		
		//compute the least distance
		double least = 0;
		
		int positionx =0;
		int positiony =0;
		double value = 0; 
		
		for(int j=0; j < distances[0].length; j++){
				least = distances[0][j];
				value = dataset[j];
				positionx = 0;
				//positiony=0;
				
		for(int i =0; i < distances.length; i++)
			{
				if(distances[i][j] < least)
				{
					least = distances[i][j] ;//+dataset[j];
					value = dataset[j];
					positionx = i;
					positiony = j;
				}
			}
		if(class_set[positionx][positiony] == Double.POSITIVE_INFINITY){
			class_set[positionx][positiony] = value;
		}
		else{
			positiony = positiony + 1;
		}
		class_set[positionx][positiony] = value;

		}

	}
	return class_set;	
	}
		/*for(int i=0; i<class_set.length; i++){
			for(int j=0; j<class_set[0].length; j++){
				System.out.println(class_set[i][j]+",");
			}
			System.out.println();
		}
		
		for(int i=0; i<distances.length; i++){
			for(int j=0; j<distances[0].length; j++){
				System.out.println(distances[i][j]+",");
			}
			System.out.println();
		}
		*/
	}
	
	/*second implementation of kmean_algo
	 *with object dataSet
	 */
	public double[][] kmean_algo(int iteration, Object[] dataset_obj)
	{
		if(dataset_obj.length < 1)
		{
			return new double[3][1];
		}
	else{
		double[] dataset = new double[dataset_obj.length];
		//System.out.println("the length of the dataset_obj array is "+dataset_obj.length);
		for(int d = 0; d < dataset_obj.length; d++){
			if(dataset_obj[d] instanceof Double){
				dataset[d] = (double)dataset_obj[d];
			}
			else{
				dataset[d] = (int)dataset_obj[d];
			}
		}
		
		//*execute this when dataset size is less than centroid size*//
		double[] dataTemp = new double[3];
		int count = dataset.length;
		
		if(count < 3){
			for(int i = 0; i < dataset.length; i++ ){
			dataTemp[i] = dataset[i];
			}
			
		dataset = null;
		dataset = dataTemp;
		}
		//***
		
		//2. centroid
	double[][] class_set = new double[3][dataset.length];
	double[] centroid = new double[3];
	//3. distances
	double[][] distances = new double[centroid.length][dataset.length];
	
		
		for(int k = 0; k < iteration; k++){
		//initialize centroids
		if( k == 0){
		centroid[0] = (double)dataset[0];
     	centroid[1] = (double)dataset[dataset.length / 2];	
		centroid[2] = (double)dataset[dataset.length - 1];

		}
		if(k > 0)
		{
			for(int i=0; i < centroid.length; i++){
				centroid[i] =sorted_out_Mean(class_set[i]);
				//System.out.println("centroid "+centroid[i]);
			}
		}
		//compute distances
		for(int j=0; j < centroid.length; j++)
			for(int i = 0; i < dataset.length; i++)
				distances[j][i] = Math.abs((double)dataset[i] - centroid[j]);
				
		for(int i = 0; i < class_set.length; i++)
			for(int j = 0; j < class_set[0].length; j++)
				class_set[i][j] = Double.POSITIVE_INFINITY;
		
		//compute the least distance
		double least = 0;
		
		int positionx =0;
		int positiony =0;
		double value = 0; 
		
		for(int j=0; j < distances[0].length; j++){
				least = distances[0][j];
				value = (double)dataset[j];
				positionx = 0;
				//positiony=0;
				
		for(int i =0; i < distances.length; i++)
			{
				if(distances[i][j] < least)
				{
					least = distances[i][j] ;//+dataset[j];
					value = (double)dataset[j];
					positionx = i;
					positiony = j;
				}
			}
		if(class_set[positionx][positiony] == Double.POSITIVE_INFINITY){
			class_set[positionx][positiony] = value;
		}
		else{
			positiony = positiony + 1;
		}
		class_set[positionx][positiony] = value;

		}
	}
		return class_set;	
	}
	}
	
	public double sorted_out_Mean(double[] arr){
		double sum = 0;
		int N = 0;
		for(int i =0; i < arr.length; i++){
			if(arr[i] != Double.POSITIVE_INFINITY){
				sum = sum + arr[i];
				N = N + 1;
				}
		}
		return sum/N;
	}
	
	public static double[] fine_tuned(double[] arr){
		int count = 0;
		int iter = 0;
		for(int i = 0; i < arr.length; i++){
			
			if(arr[i] == Double.POSITIVE_INFINITY | arr[i] == 0.0){
				continue;
			}
			else{
				count = count + 1;
			}
			
		}
		
		double[] fine = new double[count];
		for(int i = 0; i < arr.length; i++){
			
			if(arr[i] == Double.POSITIVE_INFINITY | arr[i] == 0.0){
				continue;
			}
			else{
				fine[iter] = arr[i];
				iter = iter + 1;
			}
			
		}
		return fine;
	}
/*
	public static void main(String[] args)
	{
		double[] arr = {Double.POSITIVE_INFINITY,2,3,4};
			Object[] dataset={1,2,3.3,4.5,10,11,12,23.1,30,50,7};

			double[][] v = new Kmean().kmean_algo(20, dataset);
		for(int i = 0; i < v.length; i++){
			for(int j = 0; j < v[0].length; j++){
			System.out.println(v[i][j]);
		}
		System.out.println();
		}
		
		System.out.println("mean  " +new Kmean().sorted_out_Mean(arr));

	}
*/
}