/*
 * Copyright (c) 2000, 2013, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */
 
package com.example.libjcprard;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Build;

import androidx.annotation.RequiresApi;


public class PrivatefileManager
{
	public PrivatefileManager(){

	}

	/*please read the comments below*/
	 public RectF path2d=null;
	 public Path path = null;
     public int[] pixelArray=null;
     ///private final double CANNY_THRESHOLD_RATIO = .4; //Suggested range .2 - .4 
     ///private final int CANNY_STD_DEV = 3;             //Range 1-3 
      
     //I/O parameters 
     private String imgFileName; 
     private String imgOutFile = ""; 
     private String imgExt;
	 
	 
	@RequiresApi(api = Build.VERSION_CODES.Q)
	public Bitmap setImageData(String imgFileName){
         //Read input file name and create output file name 
         //imgFileName = "testImg1."; 
		 //getter(imgFileName);
         imgExt = "jpg"; 
		 String nom=imgFileName;
		 this.imgFileName=imgFileName;
         String FullNom =imgFileName ; 
     
         imgOutFile = nom;
		 Bitmap input = null;
         //Sample JCanny usage
		System.out.println("In Private File "+FullNom);

		try {
			 //BufferedImage input = ImageIO.read(new File(FullNom)); 
			 input = BitmapFactory.decodeFile(FullNom+".txt");
			 if(input == null){
			 	System.out.println("bitmap in privatefilemanager is null");
			 }
			 else{
			 	System.out.println("bitmap in privatefilmanager is not null");
			 }
			 //input=ImageScaler.scale(input, 500,500,ImageScaler.TYPE_BICUBIC);
             input = Bitmap.createScaledBitmap(input, 500, 500, false);
			 
			 //BufferedImage output =input;//JCanny.CannyEdges(input, CANNY_STD_DEV, CANNY_THRESHOLD_RATIO); 
             Bitmap output = input;
			 
			 //ImageIO.write(output, imgExt, new File(imgOutFile));
			 
         } catch (Exception ex) { 
             System.out.println("ERROR ACCESING IMAGE FILE:\n" + ex.getMessage()); 
         } 
		 
		 ///addMouseListener(this);
        String url = imgOutFile; // this program have 4 images : wr.png ,sh.jpg , ca.jpg , icon.jpg ,r1,r2,r3,r4.jpg
        //BufferedImage image = ImageReader.load_image(url);
		Bitmap image = BitmapFactory.decodeFile(url);
		pixelArray=new int[0];
		this.pixelArray = returnArrayData(image);
		this.path2d=returnPath2D(image);
		return image;
	}
	
	@RequiresApi(api = Build.VERSION_CODES.Q)
	public int[] returnArrayData(Bitmap image){
		
       int size=(image.getWidth() + 8)*(image.getHeight() + 34);
       int arr1[]=new int[size];
       int arr2[]=new int[size];
       
       int a=0;   
       int height=image.getHeight();
       int width=image.getWidth();
     
	   int s=height*width;
	   int pix[]=new int[s];
	   
	   for(int y = 0; y < height; y++){
           for(int x = 0; x < width; x++){
        	   pix[x+y*width]=0;
           }}
	   
	   for(int y = 0; y < height; y++){
           for(int x = 0; x < width; x++){
        	   
       if(image.getColor(x,y).toArgb() > trialRelative.whitePortions()) //formally -20
        	 {       		
            	 pix[x+y*width]=1;
        	 }}}

     
	 return pix;
	 }
	 @RequiresApi(api = Build.VERSION_CODES.Q)
	 public RectF returnPath2D(Bitmap image){
		 path = new Path();
		 		 for(int y = 0; y < image.getHeight(); y++){
           for(int x = 0; x < image.getWidth(); x++){

			if(image.getColor(x,y).toArgb() > trialRelative.whitePortions())
				{
            	  //path2d.append(new Rectangle2D.Double(x,y,0,0),false);
				  path.addRect((float)x, (float)y, 0, 0, Path.Direction.CW);

				}
			}
		}
		RectF bound = new RectF();
		path.computeBounds(bound, false);
		return bound;
	 }
}