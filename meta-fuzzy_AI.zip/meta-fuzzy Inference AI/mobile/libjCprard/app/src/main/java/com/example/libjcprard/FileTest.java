/*
 * Copyright (c) 2000, 2013, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */
 
 package com.example.libjcprard;

import android.graphics.Bitmap;
import android.graphics.RectF;
import android.os.Build;

import androidx.annotation.RequiresApi;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.FileSystems;
import java.nio.file.FileVisitOption;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.EnumSet;
import java.util.Scanner;
import java.util.Vector;


public class FileTest{
static trialRelative tr=new trialRelative();
static PrivatefileManager pm=new PrivatefileManager();
Vector vector=new Vector();
private File file=null;
private BufferedWriter buff=null;
private PrintWriter pw=null;

public static int greatest=0;

//****************************//
//data record to be serialized//
//****************************//
/***************/
int size_of_label = 10;

public static double[][] test1 = null;
/********************/


@RequiresApi(api = Build.VERSION_CODES.O)
public static File enlistDirPath()
{
//Path source = FileSystems.getDefault().getPath("C:\\Program Files\\Java\\jdk1.8.0_121\\Engine_4\\img\\");
Path source = FileSystems.getDefault().getPath(System.getProperty("cprard.dir")+"/Engine_4/img/");
Path pat= FileSystems.getDefault().getPath("/");
File file=new File(System.getProperty("cprard.dir")+"/Engine_4/go.txt");
try{
	
	
	if(!file.exists()){
		//file.createNewFile();
	}
	
	BufferedWriter buff=new BufferedWriter(new FileWriter(file));
	
	final PrintWriter pw = new PrintWriter(buff);

     Files.walkFileTree(source, EnumSet.of(FileVisitOption.FOLLOW_LINKS), Integer.MAX_VALUE,
         new SimpleFileVisitor<Path>() {
            @Override
              public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs)
                  throws IOException
              {
                  return FileVisitResult.CONTINUE;
              }
			  
              @Override
              public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
                  throws IOException
              {
				  int symbolPosition=0;

				  if(!attrs.isDirectory() && Files.probeContentType(file) != null &&Files.probeContentType(file).contains("image")){
				  
				  String pos = file.getName(file.getNameCount()-2).toString();

				  String dir="";
				  for(int i=0; i < file.getNameCount(); i++){

					  dir = dir + file.getName(i) + "/"; 
					  //System.out.println("dir "+dir);
				  }
				  dir="/"+dir;

				 // System.out.println("the real dir "+dir);
				  if(Integer.valueOf(pos) instanceof Integer){
					symbolPosition=Integer.parseInt(pos);
				  }
				 // System.out.println("absolute pathname "+file.toAbsolutePath());
				  pw.write(" " + dir +" "+symbolPosition+"\n");
				  
				}
			  return FileVisitResult.CONTINUE;
			  }
			  
         });
		 pw.close();
	//buff.flush();
	buff.close();
	
}
catch(Exception e){e.printStackTrace();}
return file;
}





@RequiresApi(api = Build.VERSION_CODES.O)
public static File enlistDirPath(String path, String type, String query_name)
{
Path source = FileSystems.getDefault().getPath(path);
//Path pat= FileSystems.getDefault().getPath("/");
File file=new File(query_name);
try{
	
	
	if(!file.exists()){
		//file.createNewFile();
	}
	
	BufferedWriter buff=new BufferedWriter(new FileWriter(file));
	
	final PrintWriter pw = new PrintWriter(buff);

     Files.walkFileTree(source, EnumSet.of(FileVisitOption.FOLLOW_LINKS), Integer.MAX_VALUE,
         new SimpleFileVisitor<Path>() {
            @Override
              public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs)
                  throws IOException
              {
                  return FileVisitResult.CONTINUE;
              }
			  
              @Override
              public FileVisitResult visitFile(Path file, BasicFileAttributes attrs)
                  throws IOException
              {
				  int symbolPosition=0;

				  if(!attrs.isDirectory() && Files.probeContentType(file) != null &&Files.probeContentType(file).contains(type)){
				  
				  String pos = file.getName(file.getNameCount()-2).toString();
				  String dir="";
				  for(int i=0; i < file.getNameCount(); i++){

					  dir = dir + file.getName(i) + "/"; 
					 // System.out.println("dir "+dir);
				  }
				  dir="/"+dir;

				 //System.out.println("the real pos "+pos);
				
				   //System.out.println("absolute pathname "+file.toAbsolutePath());
				  pw.write(" " + dir +"\n");
				  
				}
			  return FileVisitResult.CONTINUE;
			  }
			  
         });
		 pw.close();
	//buff.flush();
	buff.close();
	
}
catch(Exception e){e.printStackTrace();}
return file;
}


public static Object[] readDataSet(String file) throws FileNotFoundException {
		Vector dataset = new Vector();
		Scanner scanner = null;
		Object[] string_data = null;
		try {
			int counter = 0;
			scanner = new Scanner(new File(file));
			while(scanner.hasNextLine()) {
				String line = scanner.nextLine();
				dataset.add(line);
				counter = counter + 1;
			}
		} finally {
			if (scanner != null){
				scanner.close();
			}
			string_data = dataset.toArray();
			
		}
		//System.out.println(" data arrayed ");
		return string_data;
	}
	
public static double[][] readNumericDataSet(String file) throws FileNotFoundException {
		Vector dataset = new Vector();
		Vector dataset1 = new Vector();
		Scanner scanner = null;
		Object[] string_data = null;
		double[][] end = null;
		try {
			int i = 0;
			scanner = new Scanner(new File(file));
			while(scanner.hasNextLine()) {
				String line = scanner.nextLine();
				String[] columns = line.split("\\s+");
				dataset.add(Double.parseDouble(columns[0]));	
				dataset1.add(Double.parseDouble(columns[1]));
				i = i + 1;
			}
		} finally {
			if (scanner != null){
				scanner.close();
			}
			assert dataset.size() == dataset1.size();
			end = new double[dataset.size()][2];
			
			for(int i = 0; i < end.length; i++){
				end[i][0] = (double)dataset.get(i); 
				end[i][1] = (double)dataset1.get(i); 
			}
			dataset = null;
			dataset1 = null;
		}
		System.out.println(" data arrayed ");
		return end;
	}
/*
//file should be read outside here from a separate method
try{


	//Thread thread1 = new Thread(new Runnable(){
		
	//@Override
   // public void run(){
		//if(greatest != 0){
			try{
				FileTest ft=null;
				ft=new FileTest();
				ft.init_dataset("data"+".txt");
				ft.readAndApplyCprardFileName("go.txt");
				ft.close_dataset_Buffer();
			}
			catch(IOException ioe){ioe.printStackTrace();}
		//}
	//}
	//});
	
	//	Thread thread2 = new Thread(new Runnable(){
		
	//@Override
   // public void run(){
		//try{
		//FileTest ft=new FileTest();
		//ft.init_dataset();
		//ft.readAndApplyCprardFileName("go.txt");
		//ft.close_dataset_Buffer();
		//copy_and_paste(FileSystems.getDefault().getPath("data.txt"));
		//greatest = ft.computeGreatestSize();
		///System.out.println("greatest in thread 3 "+greatest);
		//}
		//catch(IOException ioe){ioe.printStackTrace();}
	//}
	//});
	
	//Thread thread3 = new Thread(new Runnable(){
		
	//@Override
  //  public void run(){
	//try{
			
		//	FileTest ft=new FileTest();
		//	ft.init_dataset("datafinal.txt");
		//	ft.reComputeDataset(824); 
		//	ft.close_dataset_Buffer();
		//}
		//catch(IOException ioe){ioe.printStackTrace();}
	//}
	//});
	
	

}
catch(Exception e){e.printStackTrace();}
//}
*/


@RequiresApi(api = Build.VERSION_CODES.O)
public void readAndApplyCprardFileName(String textfilename) throws FileNotFoundException, IOException{
	Scanner scan=new Scanner(new File(textfilename));
	   PrivatefileManager pm= null;
	   System.out.println("b4 entering PrivateFileMan");
	   PrivatefileManager pmLearn = new PrivatefileManager();
	   RectF assrt = new RectF();
	   int[] assrtarr = new int[0];
	   Bitmap biass= null;
	   Bitmap bi=null;
	   // BufferedImage biLearn=pmLearn.setImageData("C:\\Documents and Settings\\User\\Desktop\\General Folders\\chest\\Engine - 2\\img\\0\\68.jpg");
	
	/* good code for tranversing dircetory
	String app = System.getProperty("cprard.dir");
	String[] re = app.split("/");
	String[] de = new String[re.length - 1];
	System.arraycopy(re,0,de,0, de.length);
	String joined = String.join("/", de);
	*/
	Bitmap biLearn= null;
	if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
		biLearn = pmLearn.setImageData( System.getProperty("cprard.dir")+"/EXperiment 1 Plus plus ultra - V 0.03/11.jpg");
	}


	RectF path =null;
   	   RectF pathLearn = new RectF();
	   pathLearn = pmLearn.path2d;
	   
	   int[] arr =null;
   	   int[] arrLearn = pmLearn.pixelArray;

	   vector = new Vector();
	   int train = 1;
	   int learn = 0;

	if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
		test1 = new trialRelative().rectorSolutionSpaceSimple(biLearn,pathLearn,arrLearn,0,0,350,350,learn,'z');
	}

	while(scan.hasNextLine()) {
		arr=new int[0];
		//arrLearn=;
		
		path = new RectF();
		
		
		pm = new PrivatefileManager();

		String line = scan.nextLine();
		char charcters[] = line.toCharArray();
		char label = charcters[charcters.length-1];
		String imageObj = String.valueOf(charcters, 0, charcters.length-4).trim();
		System.out.println("image object stuff vector name :"+imageObj);
		File f=new File(imageObj);
		System
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
			bi=pm.setImageData(f.getAbsolutePath());
			path = pm.path2d;
			arr = pm.pixelArray;

		}


		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
			new trialRelative().rectorSolutionSpaceSimple(bi,path,arr,0,0,350,350,train,label);// returns null
		}

		assrt = path;
		assrtarr = arr;
		biass = bi;
	  }
	  scan.close();
}


public void close_dataset_Buffer() throws IOException{
	pw.close();
	buff.close();
}


public void init_dataset(String dataset) throws IOException{
file=new File(dataset);
buff=new BufferedWriter(new FileWriter(file));
pw= new PrintWriter(buff);
}


public File readComputeCommon(Scanner scan) throws FileNotFoundException, IOException
{
		String line = scan.nextLine();
		char charcters[] = line.toCharArray();
		char label = charcters[charcters.length-1];
		String imageObj = String.valueOf(charcters, 0, charcters.length-4).trim();
		File f=new File(imageObj);
		return f;
}

@RequiresApi(api = Build.VERSION_CODES.O)
private static void copy_and_paste(Path source) throws IOException{
	//OutputStream out=null;
	InputStream in=null;
	FileOutputStream out=new FileOutputStream("copy_of_data.txt");
	Files.copy(source,out);
	//Files.copy(in,target, StandardCopyOption.REPLACE_EXISTING);
}


}