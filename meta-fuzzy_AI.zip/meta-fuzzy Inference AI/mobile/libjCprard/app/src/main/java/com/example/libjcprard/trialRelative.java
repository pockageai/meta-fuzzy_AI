/*
 * Copyright (c) 2000, 2013, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */
 
package com.example.libjcprard;







import java.util.*;
import java.io.*;


import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.RectF;
import android.os.Build;

import androidx.annotation.RequiresApi;

public class trialRelative {
private double X[]={};
private double Y[]={};
public Vector vector=null;
public Vector left=null;
public Vector right=null;

public Vector Y_left=null;
public Vector Y_right=null;

Hashtable<Double, Double> Location = null;
HashSet<Double> LocationSet = null;

public Vector accVector=new Vector();
public Vector step_acc_vector = new Vector();
public Vector step_acc_vector_1 = new Vector();
public Vector step_acc_vector_2 = new Vector();

public static int i1=0;


public static boolean drawSwitch=false;
private double constant=1;
private double constantHack = 1;//0.05;
private double size=80;
public static Object[] arr_pw=null;

trialRelative(){
	System.out.println(" before the rectorSolutionSpace function in trial's relative ");
}

/*
method for setting the value for white
*/

public static int whitePortions(){
	return -((100 << 16) | (100 << 8) | (100));
}


/*
utility for drawing rectangles around the surface objects
*/

@RequiresApi(api = Build.VERSION_CODES.Q)
public double[][] rectorSolutionSpaceSimple(Bitmap image, RectF path2D, int[] arr, double x, double y, double width, double height, int train_or_learn, char tag){
/*double x1=x;
double y1=y;
double width1=width;
double height1=height;
*/
//double y1=path2D.getBounds2D().getY();
double y1 = (double)path2D.top;

//double width1=width;
double width1 = (double)width;
 
//double height1=path2D.getBounds2D().getHeight();
double height1 = (double)(Math.abs(path2D.bottom - path2D.top));

//double x1=(path2D.getBounds2D().getX() + path2D.getBounds2D().getWidth()/2 - width/2);
double x1 = (double)(path2D.left + (Math.abs(path2D.right - path2D.left)) / 2 - width / 2);
/*if(width <= 200){
x=x-100;
width=300;
}
*/
//g.drawRect((int)Math.round(x),(int)Math.round(y),(int)Math.round(width),(int)Math.round(height));
vector=new Vector();
left=new Vector();
right=new Vector();

 Y_left=new Vector();
 Y_right=new Vector();

Location = new Hashtable<Double, Double>();
LocationSet = new HashSet<Double>();

accVector=new Vector();
step_acc_vector = new Vector();
step_acc_vector_1 = new Vector();
step_acc_vector_2 = new Vector();
// accVec=new Vector();
 
System.out.println("the value of x is "+x);
System.out.println("the value of y is "+y);
System.out.println("the value of width is "+width);
System.out.println("the value of height is "+height);

return transformedAdvancedSolutionSpace(image, path2D,arr, x1, y1, width1, height1,train_or_learn,tag);
	
}

@RequiresApi(api = Build.VERSION_CODES.Q)
public double[][] rectorSolutionSpaceSimple(Bitmap image, RectF path2D, int[] arr, int train_or_learn, char tag){
/*double x=0;
double y=0;
double width=28;
double height=28;

double x=0;
double y=0;
double width=100;
double height=100;
*/
//path2D.closePath();
//g.setColor(Color.blue);
vector=new Vector();
left=new Vector();
right=new Vector();

 Y_left=new Vector();
 Y_right=new Vector();

Location = new Hashtable<Double, Double>();
LocationSet = new HashSet<Double>();

accVector=new Vector();
step_acc_vector = new Vector();
step_acc_vector_1 = new Vector();
step_acc_vector_2 = new Vector();

//for mnist only
//double x=path2D.getBounds2D().getX();
double x = (double)path2D.left;

//double y=path2D.getBounds2D().getY();
double y = (double)path2D.top;

//double width=path2D.getBounds2D().getWidth();
double width = (double)(Math.abs(path2D.right - path2D.left));

//double height=path2D.getBounds2D().getHeight();
double height = (double)(Math.abs(path2D.bottom - path2D.top));


/*if(width <= 200){
x=x-100;
width=300;
}
*/
//g.drawRect((int)Math.round(x),(int)Math.round(y),(int)Math.round(width),(int)Math.round(height));

System.out.println("the value of x is "+x);
System.out.println("the value of y is "+y);
System.out.println("the value of width is "+width);
System.out.println("the value of height is "+height);

return transformedAdvancedSolutionSpace(image, path2D,arr, x, y, width, height, train_or_learn,tag);

}

/*
public Vector rectorSolutionSpaceSimple(BufferedImage image,Graphics2D g,Path2D.Double path2D,int[] arr,Vector vector,Vector right, Vector left){
System.out.println("entering the rectorSolutionSpace function");
int sizY=0;
int sizX=0;
int inSize=100;

for(int i=0; i<inSize; i++)
{
	for(int j=0;j<inSize;j++)
	{
	if(path2D.contains((double)i, (double)j))
	{
		System.out.println("code a");
		sizY++;
		sizX++;
	}
	}
}

int h=0;
int arrY[]=new int[sizY];
int arrX[]=new int[sizX];

for(int i=0; i<inSize; i++)
{
	for(int j=0;j<inSize;j++)
	{
	if(path2D.contains((double)i, (double)j))
	{
		System.out.println("code b");
		arrY[h]=i;
		arrX[h]=j;
		h++;
	}
	}
}

////sorting algorithm
for (int i = 0; i < arrY.length; i++){
   for (int j = 0; j < arrY.length-1 - i; j++){
	if(arrY[j] > arrY[j+1]) //aj > aj+1
	{
		System.out.println("code c");
		int temp=0;
		temp=arrY[j];
		arrY[j]=arrY[j+1];
		arrY[j+1]=temp;
					//then interchange aj and aj+1
	}
					//{a1, . . . , an is in increasing order}
  }
}


////sorting algorithm
for (int i = 0; i < arrX.length; i++){
   for (int j = 0; j < arrX.length-1 - i; j++){
	if(arrX[j] > arrX[j+1]) //aj > aj+1
	{
		System.out.println("code d");
		int temp=0;
		temp=arrX[j];
		arrX[j]=arrX[j+1];
		arrX[j+1]=temp;
					//then interchange aj and aj+1
	}
					//{a1, . . . , an is in increasing order}
  }
}
System.out.println("before the transformedAdvancedSolutionSpace function" + sizY+","+sizX);
System.out.println("the "+arrX.length);
System.out.println("the "+arrY.length);
return transformedAdvancedSolutionSpace(image, path2D,g,arr, arrX[0], arrY[0], (arrX[h-1]-arrX[0]), (arrY[h-1]-arrY[0]));


//System.out.println("the width of enclosing rectangle: "+(arrX[h-1]-arrX[0])+", the height of the enclosing rectangle: "+(arrY[h-1]-arrY[0]));
}
*/


/*
*//**
 *undergoes roots transformation
 *@param  path2D	the Path object to be utilized for making shapes
 *@param  	x		the X cordinate for enclosed rectangle
 *@param	y		the Y cordinate for enclosed rectangle
 *@param  width		the Width of the enclosed rectangle
 *@param  height 	the Height of the enclosed rectangle
 **/
	
@RequiresApi(api = Build.VERSION_CODES.Q)
public double[][] transformedAdvancedSolutionSpace(Bitmap image, RectF path2D, int ts[], double x, double y, double width, double height, int train_or_learn, char tag){


///do algorithm here
//create folders
String name = System.getProperty("cprard.dir")+"/Engine_4/cprard_data/"+tag+"";
File file = new File(name);
System.out.println(file.mkdirs());	
System.out.println("tag "+tag);	
FileWriter pw_writer = null;

//g.setColor(Color.red);
double standardY=y;
double stepx;
double stepy;
stepy=y;

double stephack;

double virtualHeight = 1000;
//y=y-50;
//height=height+50;

//Point2D.Double cp1=new Point2D.Double(-Math.sqrt(height),height);
PointF cp1 = new PointF(-(float)(Math.sqrt(height)),(float)height);

//Point2D.Double cp2=new Point2D.Double(Math.sqrt(height),height);
PointF cp2 = new PointF((float)(Math.sqrt(height)),(float)height);

//Point2D.Double cp3;
PointF cp3;

//Point2D.Double cp1Hack=new Point2D.Double(-Math.sqrt(constant*virtualHeight),virtualHeight);
PointF cp1Hack=new PointF(-(float)(Math.sqrt(constant*virtualHeight)),(float)virtualHeight);

//Point2D.Double cp2Hack=new Point2D.Double(Math.sqrt(constant*virtualHeight),virtualHeight);
PointF cp2Hack=new PointF((float)(Math.sqrt(constant*virtualHeight)),(float)virtualHeight);

//Point2D.Double cp3Hack;
PointF cp3Hack;

double[] quadCurve2d;
double[] quadCurve2dHack;

int number_of_curve_sections = 7;
arr_pw = new Object[(100 * number_of_curve_sections)];
// variable would contain the mean and variance
double[][] simplifie_info = new double[number_of_curve_sections][2]; 
double[][] hack_array = new double[number_of_curve_sections][2000];//hack_array_2
double[][] hack_array_2 = new double[number_of_curve_sections][2000];//hack_array_2
//first quadratic curve	

//s step

//actual quadratic space
//actually should be int wit = (int)Math.round((width-x)/size);
int wit = (int)Math.round((width-x)/size);
int hackInc=0;
for(int i=0; i < (int)Math.round((width-x)); i+=wit)
{
stepx=x + Math.sqrt(constant*(double)cp1.y)+i+hackInc*12;

if((hackInc/4) == number_of_curve_sections){break;}

stephack = x + Math.sqrt(constantHack*(double)cp1Hack.y) + Math.sqrt(constantHack*(double)cp1Hack.y) * hackInc;

float cx3=((cp2.y-cp1.y-2*cp2.x*cp2.x+2*cp1.x*cp1.x)/2*(cp1.x-cp2.x));
float cy3=2*cp1.x*(cx3-cp1.x)+cp1.y;
cp3=new PointF(cx3,cy3);

/*check for bug in code below as constant variable as constant variable was not multiplied to respective cps variable*/

float cx3Hack=((cp2Hack.y-cp1Hack.y-2*cp2Hack.x*cp2Hack.x+2*cp1Hack.x*cp1Hack.x)/2*(cp1Hack.x-cp2Hack.x));
float cy3Hack=2*cp1Hack.x*(cx3Hack-cp1Hack.x)+cp1Hack.y;
cp3Hack=new PointF(cx3Hack,cy3Hack);

//the quadratic array here is in the form {x1, y1, ctrlx, ctrly, x2, y2}
quadCurve2d = new double[]{cp1.x * constant + stepx, cp1.y + stepy, cx3 + stepx, cy3 + stepy, cp2.x * constant + stepx, cp2.y + stepy};
quadCurve2dHack = new double[]{cp1Hack.x * constant + stephack, cp1Hack.y + stepy, cx3Hack + stephack, cy3Hack + stepy, cp2Hack.x * constant + stephack, cp2Hack.y + stepy};


//g.setColor(Color.red);
//g.draw(quadCurve2d);
//this code blck is for getting the points for that particular 
//quadratic curve
///Most useful code the heart of cprard

EvaluateEstimation(cx3,cy3,stepy,image,path2D,x,y,stepx,stephack,quadCurve2d,quadCurve2dHack,cp1,cp2,cp1Hack,cp2Hack,width,height,virtualHeight,ts);

Object[] array = step_acc_vector.toArray();

Object[] array_1 = step_acc_vector_1.toArray();
//apply kmean to divide them
double[][] v = new Kmean().kmean_algo(20, array_1);
double[][] mean_var_1 = Gaussian.multi_dim_det_mean_and_variance(v);

Object[] array_2 = step_acc_vector_2.toArray();
//apply kmean to divide them
double[][] v2 = new Kmean().kmean_algo(20, array_2);
double[][] mean_var_2 = Gaussian.multi_dim_det_mean_and_variance(v2);

///double[] mean_var = Gaussian.det_mean_and_variance(array);

///////////////////men at work///////////
	
	try{
	file = new File(name+"\\"+"section_"+(hackInc / 4));//"\\section - "+(hackInc / 4)+"- 1.txt");
	File file2 = new File(name+"\\"+"section_"+(hackInc / 4));//+"\\section - "+(hackInc / 4)+"- 2.txt");
	if(!file.isDirectory()){
		file.mkdirs();
	}
	if(!file2.isDirectory()){
		file2.mkdirs();
	}
	file = new File(name+"\\"+"section_"+(hackInc / 4)+"\\section_"+(hackInc / 4)+"_1.txt");
	file2 = new File(name+"\\"+"section_"+(hackInc / 4)+"\\section_"+(hackInc / 4)+"_2.txt");
	
	if(!file.exists()){
	//System.out.println(file.createNewFile());
	}
	if(!file2.exists()){
	//System.out.println(file2.createNewFile());
	}

	pw_writer = new FileWriter(file, true);
	FileWriter pw_writer2 = new FileWriter(file2, true);
	for(int i1=0; i1 < mean_var_1.length; i1++){
		if(mean_var_1[i1][0] == 0 && mean_var_1[i1][1] == 0){
			mean_var_1[i1][0] = 0;
			mean_var_1[i1][1] = Double.POSITIVE_INFINITY;
		}
		pw_writer.write(mean_var_1[i1][0]+" "+mean_var_1[i1][1]);
		pw_writer.write("\n");

	}
	for(int i1=0; i1 < mean_var_2.length; i1++){
		if(mean_var_2[i1][0] == 0 && mean_var_2[i1][0] == 0){
			mean_var_2[i1][0] = 0;
			mean_var_2[i1][1] = Double.POSITIVE_INFINITY;

		}
		pw_writer2.write(mean_var_2[i1][0]+" "+mean_var_2[i1][1]);
		pw_writer2.write("\n");

	}
	//pw_writer.write(mean_var[0]+" "+mean_var[1]);
	//System.out.println("mean "+mean_var[0]);
	arr_pw[(hackInc / 4)] = pw_writer;
	pw_writer.close();
	pw_writer2.close();
	}
	catch(Exception e){
		e.printStackTrace();
	}
	
	////////////////men at work////////
	
	///System.out.println(" mean "+ mean_var[0]);
	///System.out.println(" variance "+ mean_var[1]);
	///System.out.println("position "+(hackInc / 4));
	///simplifie_info[hackInc / 4][0] = mean_var[0];
	///simplifie_info[hackInc / 4][1] = mean_var[1];
	if(train_or_learn == 0 )//&& file.exists() && file2.exists())//learn
	{
	for(int j=0; j < step_acc_vector_1.size() ; j++){
		hack_array[hackInc / 4][j] = (double)step_acc_vector_1.get(j);
		}
	
	for(int j=0; j < step_acc_vector_2.size() ; j++){
		hack_array_2[hackInc / 4][j] = (double)step_acc_vector_2.get(j);
		}
	}
hackInc = hackInc + 4;
}

double[][] return_stat = null;
//byte hackarray_ad=null;
if(train_or_learn == 1)//train
{
	return_stat = null;
}
if(train_or_learn == 0)//learn
{
	int count1=0,count2=0;
	double[][] hack_array_final = new double[hack_array.length + hack_array_2.length][hack_array[0].length];
	for(int i=0; i < (hack_array.length + hack_array_2.length); i++){
		if(i % 2 == 0){
			hack_array_final[i] = hack_array[count1];
			count1 = count1+1;
		}
		if(i % 2 == 1){
			hack_array_final[i] = hack_array_2[count2];
			count2 = count2+1;
		}
	}
	return_stat = hack_array_final; 
}
return return_stat;
}

@RequiresApi(api = Build.VERSION_CODES.Q)
private void EvaluateEstimation(double cx3, double cy3, double stepy, Bitmap image, RectF path2D, double x, double y, double stepx, double stephack, double[] quadCurve2d, double[] quadCurve2dHack, PointF cp1, PointF cp2, PointF cp1Hack, PointF cp2Hack, double width, double height, double virtualHeight, int[] ts)
{
step_acc_vector = null;
step_acc_vector = new Vector();

step_acc_vector_1 = null;
step_acc_vector_1 = new Vector();

step_acc_vector_2 = null;
step_acc_vector_2 = new Vector();
	
int count=0;
int size=1;

//g.drawRect(0,0,(int)Math.round(width)+(int)Math.round(x),(int)Math.round(height)+(int)Math.round(y));
for(int i=0; i < width+(int)x; i++){
	for(int j=0; j < height+(int)y; j++){
		//if(quadCurve2d.contains(i,j))
		if(contains(quadCurve2d, i, j) && (!contains(quadCurve2d, i+1, j) || !contains(quadCurve2d, i-1, j) || !contains(quadCurve2d, i+1, j+1) || !contains(quadCurve2d, i-1, j-1) || !contains(quadCurve2d, i, j+1) || !contains(quadCurve2d, i, j-1) || !contains(quadCurve2d, i+1, j-1) || !contains(quadCurve2d, i-1, j+1)))
		{
			//quadArry[(int) (i+j*width)]=1;
			size++;
			
		}
		else
		{
			//quadArry[(int) (i+j*width)]=0;
		}
	}
}
double axel=0;
double axelHack=0;
double div=0;
int arrx[]=new int[size];
int arry[]=new int[size];
for(int j=0; j < height+(int)y; j++){
	for(int i=0; i < width+(int)x; i++){

		//if(quadCurve2d.contains(i,j))
		if(contains(quadCurve2d, i, j) && (!contains(quadCurve2d, i+1, j) || !contains(quadCurve2d, i-1, j) || !contains(quadCurve2d, i+1, j+1) || !contains(quadCurve2d, i-1, j-1) || !contains(quadCurve2d, i, j+1) || !contains(quadCurve2d, i, j-1) || !contains(quadCurve2d, i+1, j-1) || !contains(quadCurve2d, i-1, j+1)))
		{
			//quadArry[(int) (i+j*width)]=1;
			
			arrx[count]=i;
			arry[count]=j;
			count++;
			//g.setColor(Color.blue);	
			//g.setColor(Color.blue);
			//g.drawRect(i,j,0,0);
			if(image.getColor(i,j).toArgb() > trialRelative.whitePortions())//it was formally -20
        	 {
				//g.setColor(Color.blue);
            	//g.drawRect(i,j,0,0);
				
				//the quadratic array here is in the form {x1, y1, ctrlx, ctrly, x2, y2}
				
				if(i > stepx )
				{//System.out.println("intersection");
			//g.setColor(Color.blue);
					//axel=stepx + Math.sqrt(constant * Math.abs(y-j));
					axel=stepx + Math.sqrt(Math.abs(j));
					axelHack=stephack + Math.sqrt(constantHack * (double)(Math.abs(j) / height) * virtualHeight);
					//System.out.println("on my right AXEL"+ axel);
					
				right.addElement((quadCurve2dHack[2]*constantHack+Math.sqrt(constantHack * (double)(Math.abs(y-j) / height) * virtualHeight)));
			///	Y_right.addElement((y-j));
			Location.put(Math.floor((double)(quadCurve2dHack[2]*constantHack + Math.sqrt(constantHack * (double)(Math.abs(y-j) / height) * virtualHeight))-x),(double)(j));
			LocationSet.add(Math.floor((double)(Math.abs(y-j) / height) * virtualHeight));
			//	right.addElement((quadCurve2d.getX2()*constant+axel));
								
					//vector.addElement((cp1.getX()*constant+axel*div));
					//vector.addElement((quadCurve2d.getX1()*constant+axel));
					//vector.addElement((quadCurve2d.getX2()*constant+axel));
					//accVector.addElement(Math.sqrt(Math.abs(j)));
			accVector.addElement((quadCurve2dHack[2]*constantHack+Math.sqrt(constantHack * (double)(Math.abs(y-j) / height) * virtualHeight) + quadCurve2dHack[0]*constantHack));
			step_acc_vector.addElement((quadCurve2dHack[2]*constantHack+Math.sqrt(constantHack * (double)(Math.abs(y-j) / height) * virtualHeight) + quadCurve2dHack[0]*constantHack));
			step_acc_vector_1.addElement((quadCurve2dHack[2]*constantHack+Math.sqrt(constantHack * (double)(Math.abs(y-j) / height) * virtualHeight) + quadCurve2dHack[0]*constantHack));

			//accVector.addElement(quadCurve2d.getCtrlX()*constant + Math.sqrt(Math.abs(y-j)));
					//accVector.addElement((quadCurve2dHack.getX1()*constantHack+axelHack));
				//	accVector.addElement((quadCurve2dHack.getX2()*constantHack+axelHack));
				//	vector.addElement((axel));
				
				//g.draw(new QuadCurve2D.Double(cp1.getX()*constant+axel,cp1.getY()+stepy,cx3+axel,cy3+stepy,cp2.getX()*constant+axel,cp2.getY()+stepy));
					//g.draw(new QuadCurve2D.Double(cp1.getX()-axel,cp1.getY()+stepy,cx3-axel,cy3+stepy,cp2.getX()-axel,cp2.getY()+stepy));
					//g.drawRect((int)(cp1.getX()*constant+div),(int)y,1,1);
					//g.drawRect((int)(cp2.getX()*constant+div),(int)y,1,1);
				}
				if(i < stepx)
				{//System.out.println("intersection");
					//axel=stepx - Math.sqrt(constant * Math.abs(y-j));
					//g.setColor(Color.blue);
					axelHack=stephack - Math.sqrt(constantHack * (double)(Math.abs(y-j) / height) * virtualHeight);
					axel=stepx - Math.sqrt(Math.abs(j));
					div=Math.exp(Math.sqrt(constant * Math.abs(height-(height-j)))/width);
					//System.out.println("on my left");
					//System.out.println("axel -------------------------"+ (axel));
				//g.setColor(Color.black);
					
					left.addElement((quadCurve2dHack[2]*constantHack-Math.sqrt(constantHack * (double)(Math.abs(y-j) / height) * virtualHeight)));
				///	Y_left.addElement((y-j));
					Location.put(Math.floor((double)(quadCurve2dHack[2]*constantHack - Math.sqrt(constantHack * (double)(Math.abs(y-j) / height) * virtualHeight) - x)),(double)(j));
					//Location.put(Math.floor((double)(quadCurve2dHack.getCtrlX()*constantHack - Math.sqrt(constantHack * (double)(Math.abs(y-j) / height) * virtualHeight) - x)),((double)(Math.abs(y-j) / height) * virtualHeight));
					
					LocationSet.add(Math.floor((double)(Math.abs(y-j) / height) * virtualHeight));
					//left.addElement((quadCurve2d.getX2()*constant+axel));
					
		//	accVector.addElement(quadCurve2d.getCtrlX()*constant - Math.sqrt(Math.abs(y-j)));
					//vector.addElement((quadCurve2d.getX1()*constant-axel));
					//vector.addElement((quadCurve2d.getX2()*constant-axel));
					
				
					//accVector.addElement(Math.sqrt(constantHack * (double)(Math.abs(j) / height) * virtualHeight) * 1.9);
					
			accVector.addElement((quadCurve2dHack[2]*constantHack-Math.sqrt(constantHack * (double)(Math.abs(y-j) / height) * virtualHeight) + quadCurve2dHack[0]*constantHack));
			step_acc_vector.addElement((quadCurve2dHack[2]*constantHack-Math.sqrt(constantHack * (double)(Math.abs(y-j) / height) * virtualHeight) + quadCurve2dHack[0]*constantHack));
			step_acc_vector_2.addElement((quadCurve2dHack[2]*constantHack-Math.sqrt(constantHack * (double)(Math.abs(y-j) / height) * virtualHeight) + quadCurve2dHack[0]*constantHack));

					//accVector.addElement((quadCurve2dHack.getX2()*constantHack-axelHack));
					
				/*	if((cp1.getX()*constant-axel) < 0 ){
						System.out.println("axel ) "+ axel);
						System.out.println("cp1.getX()*const ant-axel -------------------------"+ (cp1.getX()*constant));
						g.drawLine((int)(cp1.getX()*constant +axel),0,(int)(cp1.getX()*constant  + axel ),500);
					}
					
				if((cp2.getX()*constant-axel) < 0 ){
						System.out.println("axel ) "+ axel);
						System.out.println("cp2.getX()*constant-axel -------------------------"+ (cp2.getX()*constant));
						g.drawLine((int)(cp2.getX()*constant +  axel),0,(int)(cp2.getX()*constant + axel ),500);
					
					}
				*/
				//	vector.addElement((-axel));
					//g.setColor(Color.green);
				//g.draw(new QuadCurve2D.Double(cp1.getX()*constant+axel,cp1.getY()+stepy,cx3+axel,cy3+stepy,cp2.getX()*constant+axel,cp2.getY()+stepy));
					//g.draw(new QuadCurve2D.Double(cp1.getX()-axel,cp1.getY()+stepy,cx3-axel,cy3+stepy,cp2.getX()-axel,cp2.getY()+stepy));
					//g.setColor(Color.blue);
					//g.drawRect(-(int)(cp2.getX()*constant+div),(int)y,100,100);
					//g.drawRect(-(int)(cp2.getX()*constant+div),(int)y,100,100);
				}
				if(i == stepx)
				{
					axel=stepx;
					//System.out.println("on my right AXEL"+ axel);
					//System.out.println("intersection");
					//g.draw(new QuadCurve2D.Double(cp1.getX()*constant,cp1.getY()+stepy,cx3,cy3+stepy,cp2.getX()*constant,cp2.getY()+stepy));
					vector.addElement((cp1.x*constant));
					vector.addElement((cp2.x*constant));
					
					//accVector.addElement(axel);
					//accVector.addElement(axel);
					
				}
			
			
			
			}
			
		}
		else
		{
			//quadArry[(int) (i+j*width)]=0;
		}
	}

}





//determine if the quadratic curve and the pixel have the same state

}
public boolean contains(double[] quadCurve2d, double x, double y) {

        double x1 = quadCurve2d[0]; // the x1 of QuadCurve2D
        double y1 = quadCurve2d[1]; // the y1 of QuadCurve2D
        double xc = quadCurve2d[2]; // the ctrlx of QuadCurve2D
        double yc = quadCurve2d[3]; // the ctrly of QuadCurve2D
        double x2 = quadCurve2d[4]; // the x2 of QuadCurve2D
        double y2 = quadCurve2d[5]; // the y2 of QuadCurve2D

        /*
         * We have a convex shape bounded by quad curve Pc(t)
         * and ine Pl(t).
         *
         *     P1 = (x1, y1) - start point of curve
         *     P2 = (x2, y2) - end point of curve
         *     Pc = (xc, yc) - control point
         *
         *     Pq(t) = P1*(1 - t)^2 + 2*Pc*t*(1 - t) + P2*t^2 =
         *           = (P1 - 2*Pc + P2)*t^2 + 2*(Pc - P1)*t + P1
         *     Pl(t) = P1*(1 - t) + P2*t
         *     t = [0:1]
         *
         *     P = (x, y) - point of interest
         *
         * Let's look at second derivative of quad curve equation:
         *
         *     Pq''(t) = 2 * (P1 - 2 * Pc + P2) = Pq''
         *     It's constant vector.
         *
         * Let's draw a line through P to be parallel to this
         * vector and find the intersection of the quad curve
         * and the line.
         *
         * Pq(t) is point of intersection if system of equations
         * below has the solution.
         *
         *     L(s) = P + Pq''*s == Pq(t)
         *     Pq''*s + (P - Pq(t)) == 0
         *
         *     | xq''*s + (x - xq(t)) == 0
         *     | yq''*s + (y - yq(t)) == 0
         *
         * This system has the solution if rank of its matrix equals to 1.
         * That is, determinant of the matrix should be zero.
         *
         *     (y - yq(t))*xq'' == (x - xq(t))*yq''
         *
         * Let's solve this equation with 't' variable.
         * Also let kx = x1 - 2*xc + x2
         *          ky = y1 - 2*yc + y2
         *
         *     t0q = (1/2)*((x - x1)*ky - (y - y1)*kx) /
         *                 ((xc - x1)*ky - (yc - y1)*kx)
         *
         * Let's do the same for our line Pl(t):
         *
         *     t0l = ((x - x1)*ky - (y - y1)*kx) /
         *           ((x2 - x1)*ky - (y2 - y1)*kx)
         *
         * It's easy to check that t0q == t0l. This fact means
         * we can compute t0 only one time.
         *
         * In case t0 < 0 or t0 > 1, we have an intersections outside
         * of shape bounds. So, P is definitely out of shape.
         *
         * In case t0 is inside [0:1], we should calculate Pq(t0)
         * and Pl(t0). We have three points for now, and all of them
         * lie on one line. So, we just need to detect, is our point
         * of interest between points of intersections or not.
         *
         * If the denominator in the t0q and t0l equations is
         * zero, then the points must be collinear and so the
         * curve is degenerate and encloses no area.  Thus the
         * result is false.
         */
        double kx = x1 - 2 * xc + x2;
        double ky = y1 - 2 * yc + y2;
        double dx = x - x1;
        double dy = y - y1;
        double dxl = x2 - x1;
        double dyl = y2 - y1;

        double t0 = (dx * ky - dy * kx) / (dxl * ky - dyl * kx);
        if (t0 < 0 || t0 > 1 || t0 != t0) {
            return false;
        }
	
        double xb = kx * t0 * t0 + 2 * (xc - x1) * t0 + x1;
        double yb = ky * t0 * t0 + 2 * (yc - y1) * t0 + y1;
        double xl = dxl * t0 + x1;
        double yl = dyl * t0 + y1;
			
		if((x == xb && y == yb) || (x == xl && y == xl)){
			//g.setColor(Color.blue);
			//g.drawLine((int)x,(int)y,(int)x,(int)y);
		}
       return (x >= xb && x < xl) ||
               (x >= xl && x < xb) ||
               (y >= yb && y < yl) ||
               (y >= yl && y < yb);
    }


}