
This is a sample of the original package yet to be made into a library

FOLDERNAME: Engine_4
DESCRIPTION: contains the files below  
	
	FOLDERNAME: cprard_data
	DESCRIPTION: pre-modeled data on MNIST training set
	
	FOLDERNAME: img
	DESCRIPTION: prepared data on MNIST based validation set from 0 to 9
	
	filename: Entry.java
	description: This class contains the main function 

	filename: FileContentManager.java
	description: This contains file operations to the AI technique

	filename: ImageNumberConvertor.java
	description: This is where image pixel is basically converted into number

	filename: SelectionEngine.java
	description: This is the backbone of the process it is a data selection algorithm

	filename: ProbabilityEstimate.java
	description: The probability Estimation technique

	filename: Kmean.java
	description: custom kmean algorithm

	filename: Gaussian.java
	description: custom gaussian functions

	filename: ImageReader.java
	description: custom image reader

	filename: ImageScalar.java
	description: custom image scaler

FOLDERNAME: testset
DESCRIPTION: contains images from MNIST testing set  