/*
 * Copyright (c) 2000, 2013, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */
 
package com.example.libjcprard;

import android.os.Build;

import androidx.annotation.RequiresApi;

import java.io.*;
import java.math.*;
import java.util.*;
public class ConsumerCp{
	
	public ConsumerCp()
	{
	Consumer1 consumer1 = new Consumer1();
	//Consumer2 consumer2 = new Consumer2();
	consumer1.start();
	//consumer2.start();
	}
}

class Consumer1 extends Thread{
Producer producer;
int counter = 0;

	public Consumer1(){
		producer = new Producer(this);
		producer.start();
	}
	
	@RequiresApi(api = Build.VERSION_CODES.O)
	public void run(){
	//while(counter < 1){
	showMessage();
	//counter+=1;
	//}
	}
	
	@RequiresApi(api = Build.VERSION_CODES.O)
	public synchronized void showMessage(){
	try{
	wait();
	}
	catch(InterruptedException ie){
		return;
	}
	int value=producer.getValue();
	File file = producer.getFile();
	System.out.println("consumer1 "+value);
	System.out.println("Consumer File "+file);
		
	try{
				
				FileTest ft=new FileTest();
				ft.init_dataset(System.getProperty("cprard.dir")+"/Engine_4/data.txt");
				System.out.println(" enter ");
				ft.readAndApplyCprardFileName(file.toString().trim());
				//String base_dir = new RootStringHandler().getName();//assign something to it

				//trying something here
				double[][] arr_of_dat = null;
				double probs = 1;
				double[][] data_to_be_examined = FileTest.test1;//data to be classified
				HashMap<Integer, Double> Hmap = new HashMap<Integer, Double>();
				for(int j = 0; j < 10; j++){
				String tag = ""+j; //for i = 0
				String nom = System.getProperty("cprard.dir")+"/Engine_4/cprard_data/"+tag;
				FileTest.enlistDirPath(nom, "text", System.getProperty("cprard.dir")+"/Engine_4/end_product_"+tag+".txt");
				Object[] arr_of_STring = FileTest.readDataSet(System.getProperty("cprard.dir")+"/Engine_4/end_product_"+tag+".txt");
				System.out.println("tag 1 "+ tag);
				//System.out.println(Math.log(9.38E-196) * Math.log(2.542E-82) * Math.log(1.462E-81));
				//
				probs = 0;
				for(int i =0; i < arr_of_STring.length; i++){
					arr_of_dat = FileTest.readNumericDataSet(((String)arr_of_STring[i]).trim());//parameters from file
					probs = probs + Math.log(Symple_Math_Theory.example_1(arr_of_dat, data_to_be_examined[i]));
					//System.out.println(" Symple_Math_Theory  "+Symple_Math_Theory.example_1(arr_of_dat, data_to_be_examined[i]));
					System.out.println(" probability "+probs);
				}
				Hmap.put(j, probs);
				System.out.println();
				System.out.println();
				}
				
				///discriminate the set to make useful prediction///
				//Vector vector = (Vector)Hmap.values();
				Object[] array_of_class = Hmap.values().toArray();
				double[] arr_of_class_double = new double[array_of_class.length];
				for(int i = 0; i < array_of_class.length; i++){
					if(array_of_class[i] instanceof Double){
						arr_of_class_double[i] = (double)array_of_class[i];
					}
					else{
						arr_of_class_double[i] = (int)array_of_class[i];
					}
				}
				
				Arrays.sort(arr_of_class_double);
				double talk_of_code_town = arr_of_class_double[arr_of_class_double.length - 1]; 
				Set<Integer> keys = Hmap.keySet();
				//System.out.println(keys.iterator().hasNext());
				Iterator iterator = keys.iterator();

				while(iterator.hasNext()){
					int k = (int)iterator.next();
					if(talk_of_code_town == (double)Hmap.get(k)){
						System.out.println("the image is "+k);
					}
					
				}

				System.out.println();
				ft.close_dataset_Buffer();
				System.out.println(" leave ");
				
				//
				
			/*	Object[] arr = trialRelative.arr_pw;
				for(int d = 0; d < arr.length; d++){
				if(arr[d] == null){continue;}
				else{
				((PrintWriter)arr[d]).close();
				}
}
				*/
			}
			catch(IOException ioe){ioe.printStackTrace();}
	}
	
	
	
	public double[] remove_zeros(double[] test1)
	{
		int count = 0;
			for(int i=0; i < test1.length; i++)
			{
				if(test1[i] !=  0){
					count=count+1;
				}
			}
			double[] final_test = new double[count];
			//System.out.println(" count "+count);
			//System.out.println(" test1.length "+test1.length);
			for(int i=0; i<count; i++){
				final_test[i] = test1[i];
			}
		return final_test;
	}

}
/*
class Consumer2 extends Thread{
Producer producer;
int counter = 0;

	public Consumer2(){
		producer = new Producer(this);
		producer.start();
	}
	
	public void run(){
	while(counter < 10){
	showMessage();
	counter+=1;
	}
	}
	
	public synchronized void showMessage(){
	try{
	wait();
	}
	catch(InterruptedException ie){
		return;
	}
	int value=producer.getValue();
	System.out.println("consumer2 "+value);
	}
}
*/
class Producer extends Thread{
Object monitor;
int counter=0;
int value=0;
File file;

	public Producer(Object monitor){
		this.monitor = monitor;
	}
	
	@RequiresApi(api = Build.VERSION_CODES.O)
	public void run(){
	//while(counter<1){ 
	try{
		sleep(0);
	}
	catch(InterruptedException ie){
		return;
	}
	sendMessage();
	counter+=1;
	//}
	}
	
	@RequiresApi(api = Build.VERSION_CODES.O)
	void sendMessage(){
	//make message ready then notify waiter
	 value += 1;
	 
	 file = FileTest.enlistDirPath();
	 
	 System.out.println("Producer "+value);
	 System.out.println("Producer file "+file);
	 synchronized(monitor){
	 monitor.notify();
	 }
	}
	
	public int getValue(){
	return value;
	} 
	
	public File getFile(){
		return file;
	}
}