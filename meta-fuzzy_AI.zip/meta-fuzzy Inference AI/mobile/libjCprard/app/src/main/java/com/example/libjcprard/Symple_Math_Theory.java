/*
 * Copyright (c) 2000, 2013, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */
 
package com.example.libjcprard;

public class Symple_Math_Theory{
	double[][] arr(){
		return null;
	}
	public static void main(String[] args){
		/*double num = 10 - Double.NEGATIVE_INFINITY;
		System.out.println("the number is "+num);
		
		double num2 = Double.POSITIVE_INFINITY - Double.POSITIVE_INFINITY +1;
		System.out.println("the second number is "+num2);
		
		System.out.println(" the value "+new double[0][0]);
		System.out.println(" the value "+new Symple_Math_Theory().arr());
		
		for(int i = 0; i < 10; i++){
				if(i % 2 == 0)
					System.out.println("even " + i);
				
				if(i % 2 == 1)
					System.out.println("odd " + i);
			}
			*/
		double[][] arr_1 = {{1,0.2},{67,0.66},{1000,0.999}};
		Object[] arr_2 = {2.1,3.2,1.0,14.8,15.9,16,30,31,32,34,36};
		//Object[][] a1 = arr_1;
		//System.out.println(" returned here "+example_1(arr_1, arr_2));
		double[] n1 = {19,20};
		double[] p11 = Gaussian.oneD_gaussian_analytics1(n1,2.5,1.25);
		double prod = 1;
		for(int i=0; i < p11.length; i++){
			prod = prod * p11[i];
		}
		System.out.println("probab "+ prod);
		
		p11 = Gaussian.oneD_gaussian_analytics1(n1,34.6667,2.9);
		prod = 1;
		for(int i=0; i < p11.length; i++){
			prod = prod * p11[i];
		}
		System.out.println("probab "+ prod);
		
		p11 = Gaussian.oneD_gaussian_analytics1(n1,19,2);
		prod = 1;
		for(int i=0; i < p11.length; i++){
			prod = prod * p11[i];
		}
		System.out.println("probab "+ prod);
		}
		
		public static double example_1(double[][] arr_1, double[] arr_2)// initially double[] arr_2 was Object[] arr_2
		{
			//#removezerosfromtrialdata
				
			double[] arr_2_refined = Kmean.fine_tuned(arr_2);
			
			double[][] arr = new Kmean().kmean_algo(100, arr_2_refined);
			double sum = 0;
			double product = 1;
			double[] arr_fine=null;
			
			for(int i = 0; i < arr.length; i++){
				for(int j = 0; j < arr_1.length; j++){
					 arr_fine = Kmean.fine_tuned(arr[i]);
					 sum = sum + Gaussian.oneD_gaussian_probability_multiply(arr_fine, arr_1[j][0],arr_1[j][1]);
					/* if( arr_1[j][1] == 0){
						System.out.println(" gaussian    "+ Gaussian.oneD_gaussian_probability_multiply(arr_fine, arr_1[j][0],arr_1[j][1]));
						System.out.print("   arr_1[j][0]  "+arr_1[j][0]);
						System.out.print("   arr_1[j][1]  "+arr_1[j][1]);
						
						//for(int ii = 0; ii < arr_fine.length; ii++){
							//if(arr_fine[ii] == 0){
						//		System.out.println("arr_fine "+arr_fine[ii]+" ");
							//}
						//}
					 }*/
					 
					 
				}
				
			product = product * sum;
			}
			System.out.println("product "+product);	
			return product;
		}
}