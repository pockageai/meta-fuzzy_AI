/*
 * Copyright (c) 2000, 2013, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */
 
package com.example.libjcprard;

import java.util.Vector;
/*1. with gaussian mixture model two parameters are easily computed the mean and the variance
 *2. product of gaussian distributions form gaussians
 *3. central limit theorem: mean of any random variables converges to gaussian
*/ 
public class Gaussian
{
	public static double variance = 0;
	public static double mean = 0;
	
	public static double[][] multi_dim_det_mean_and_variance(double[][] input){
		
		double[][] output = new double[input.length][2];
		
		
		
		int iter = 0;
		for(int i = 0; i < input.length; i++){
			///////code to remove zeros//////////
			
			///////code to remove zeros///////////////
			//input[i] = fn_input;
			
			///if(input[i].length > 0)
			///{
			//System.out.println("value of i "+i);
			output[i] = Gaussian.det_mean_and_variance(input[i]);				
			///iter = iter + 1;
			///}
		}
		int count = 0;
		for(int i = 0; i < output.length; i++){
			//for(int j = 0; j < output[0].length; j++){
				if( Double.isNaN(output[i][0]) || Double.isNaN(output[i][1]))
				{
					//System.out.println("out p "+output[i][0]);
					continue;
				}
				else{
					count = count + 1;
				}
			//}
		}
		//System.out.println("count "+count);
		double[][] ret_output = new double[count][2];
		int step = 0;
		for(int i = 0; i < output.length; i++){
			//for(int j = 0; j < output[0].length; j++){
				if( Double.isNaN(output[i][0]) || Double.isNaN(output[i][1]))
				{
					//System.out.println("out p "+output[i][0]);
					continue;
				}
				else{
					ret_output[step] = output[i];
					step = step + 1;
				}
			//}
		}
		
		return ret_output;
	}
	
	public static double[] det_mean_and_variance(double[] obj1)
	{
		//double[] obj = new double[obj1.length];
		Vector obj_vector = new Vector();
		
		int counter = 0;
		for(int d = 0; d < obj1.length; d++)
		{
			//if(obj1[d] instanceof Double){
			if(obj1[d] == Double.POSITIVE_INFINITY || obj1[d] == Double.NEGATIVE_INFINITY){
				continue;
			}
			else{
				//System.out.println("object "+obj1[d]);
				obj_vector.addElement(obj1[d]);
			}
		 }
		//System.out.println("vector size "+obj_vector.size());
		Object[] obj_obj = obj_vector.toArray();
		double[] obj = new double[obj_obj.length];
		
		for(int d = 0; d < obj_obj.length; d++){
			if(obj_obj[d] instanceof Double){
				obj[d] = (double)obj_obj[d];
			}
			else{
				obj[d] = (int)obj_obj[d];
			}
		}
		
		double[] mean_variance = new double[2];
		int N = obj.length;
		double sum_of_obj = 0;
		double deviation_squared = 0;
		
		for(int i=0; i < obj.length; i++)
		{
			sum_of_obj = sum_of_obj + obj[i];
		}
		//System.out.println("sum_of_x " +sum_of_x);
		
		mean = sum_of_obj / N;
		
		if(N == 1){
			variance = 0.1;
		}
		else{
		for(int i=0; i < obj.length; i++)
		{
			deviation_squared = deviation_squared + Math.pow(((double)obj[i] - mean), 2);
			//System.out.println("deviation_squared "+ deviation_squared);
			//System.out.println("obj[i] "+ obj[i]);
			//System.out.println("mean "+ mean);
		}
		
		variance = deviation_squared / N;
		if(variance == 0){variance = 0.1;}
		}
		/*if(variance == 0){
		System.out.println("mean "+ mean);
		System.out.println("N "+ N);
		System.out.println("variance "+ variance);
		for(int i=0; i < obj.length; i++)
		{
			deviation_squared = deviation_squared + Math.pow(((double)obj[i] - mean), 2);
			System.out.println("step deviation_squared "+ deviation_squared);
			//System.out.println("obj[i] "+ obj[i]);
			//System.out.println("mean "+ mean);
		}
				System.out.println("deviation_squared "+ deviation_squared);

		}*/
		if(variance == 0){System.out.println("varinace still zeroS");}
		mean_variance[0] = mean;
		mean_variance[1] = variance;
		return mean_variance;
	}
	
	
	
	public static double[] oneD_gaussian_analytics(double[] x)
	{
		double[] cleandata = new double[x.length - 1];
		
		for(int i = 0; i < cleandata.length; i++)
			cleandata[i] = x[i];
		
		
		//x = cleandata; 
		
		int N = x.length;
		//System.out.println("NUMBER                               " +N);
		double[] probability_of_x = new double[x.length];

		double sum_of_x = 0;
		double deviation_squared = 0;
		
		for(int i=0; i < x.length; i++)
		{
			sum_of_x = sum_of_x + x[i];
			
		}
		//System.out.println("sum_of_x " +sum_of_x);
		
		mean = sum_of_x / N;
		
		//System.out.println("mean "+ mean);
		
		
		for(int i=0; i < x.length; i++)
		{
			deviation_squared = deviation_squared + Math.pow((x[i] - mean), 2);
			
		}
		//System.out.println("deviation_squared "+ deviation_squared);
		
		variance = deviation_squared / N;
		
		//System.out.println("variance "+ variance);
		
		for(int i=0; i < x.length; i++){
		probability_of_x[i] = Math.exp(-Math.pow((x[i] - mean), 2)/(2 * Math.pow(variance,2))) / (Math.sqrt(2*Math.PI) * variance);
		}
		return probability_of_x;
	}
	
	public static double[] oneD_gaussian_analytics1(double[] x, double mean, double variance)
	{
		
		double[] probability_of_x = new double[x.length];

		for(int i=0; i < x.length; i++){
		probability_of_x[i] = Math.exp(-Math.pow((x[i] - mean), 2)/(2 * Math.pow(variance,2))) / (Math.sqrt(2*Math.PI) * variance);
		}
		return probability_of_x;
	}
	
	public static double oneD_gaussian_probability_multiply(double[] x, double mean, double variance)
	{
		double[] probability = oneD_gaussian_analytics1(x, mean, variance);
		double product = 1;
		for(int i=0; i < probability.length; i++){
			product = product * probability[i];
			//System.out.println(" inner probability "+ probability[i]);
		}
		
		return product;
	}
	
	public double multiD_gaussian_analytics(double[] x)
	{
		
		return 0;
	}
	
	
	
	public static void main(String[] args)
	{/*
		System.out.println("trickatree");
		double[] x = {1,2,3,7,8,4,5,6,7.1,8.1};
		double[] x1 ={0,0.11,0.1,0.21,0.3,0.4,0.5,0.6,0.8,0.9};
		double[] res = oneD_gaussian_analytics(x);
		
		double[] res1 = oneD_gaussian_analytics1(x1, mean, variance); 
		for(int i = 0; i < x.length; i++)
		{
			System.out.println(x[i]+" "+res[i]);
			System.out.println(x1[i]+" "+res1[i]+"\n");

		}
	*/	
		double[][] input = {{},{Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY,5,Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY},{23,3,4,5,76,5}};
		
		double[][] output = new double[input.length][2];
		
		for(int i = 0; i < input.length; i++){
			output[i] = Gaussian.det_mean_and_variance(input[i]);
		}
		
		for(int i = 0; i < output.length; i++){
			for(int j = 0; j < output[0].length; j++){
				System.out.print(" "+output[i][j]+" ");
			}
			System.out.println();
		}
		
		double[][] output1 = Gaussian.multi_dim_det_mean_and_variance(input);
		for(int i = 0; i < output1.length; i++){
			for(int j = 0; j < output1[0].length; j++){
				if(output1[i][j] == (0.0d / 0.0))
				{
					System.out.println("hell no");
				}
				System.out.print(" "+output1[i][j]+" ");
			}
			System.out.println();
		}
		
		
		
		//System.out.println("check out "+ (double)(Math.sqrt(2*Math.PI) * variance));
		//System.out.println("check out twice "+ (double) 2 * (Math.sqrt(2*Math.PI) * variance));
	}
}